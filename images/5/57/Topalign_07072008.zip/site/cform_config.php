<?php
 error_reporting(0);
  
  // configuration
  $page_title = "TopAlign";
  $email_it_to = "topalign@gmail.com";
  $error_message = "Please complete the form first";
  $confirmation = "Thank you, your message has been successfully sent. please feel free to contact me on mobile: +91 9895 933339";
?>