
<?
error_reporting(0);
?>
<head>
<meta name="verify-v1" content="cpHTvPz2TxMrD7niqH052dACfmhsvvNsrUaRTJpI7K4=" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>&gt;&gt; topalign &lt;&lt; Mr.Elayidom, we design for you,  SEO expert, html expert, Flash Expert, UI Expert, user interface, technopark, infopark, kerala, india, Thodupuzha, web designer, ui designer, grapic designer</title>
<meta name="description" content="JJ Elayidom, we design for you,  SEO expert, html expert, Flash Expert, UI expert, user interface,  world wide web design,  world wide web designer,   technopark, infopark, kerala, Thodupuzha, india, web designer, Cheap rate Web Site Designing,  ui designer, Outsource to india, one month designer, Designer at  = 15000Rs/month">
    <meta name="keywords" content="Mr.JJ Elayidom, we design for you, SEO expert, html expert, Flash Expert, UI Expert, user interface, world wide web designer, Cheap rate Web Site Designing wold,   technopark, infopark, kerala, india, web designer, ui designer, Designer at  = 15000Rs/month">
    <meta name="copyright" content="www.topalign.com">
    <meta name="author" content="layidom">
    <meta name="Distribution" content="Global">
<style>
body {
	background: #f6005d;
	margin: 0; padding: 0;
	font-family:Verdana, Arial, Helvetica, sans-serif;
	}
.style1 {font-size: 5px; color:#f6005d;}
.FORM td{ color:#FFFFFF; font-size:11px;}
.brd {border: 0px solid #CCCCCC;}
.mg {margin: 5px;}
#returned_value{text-align:center;font-size:12px;color:#000000}
#go, input{border:1px solid #CCCCCC;background:#FFF}

.style2 {color: #000000}
</style>
<script type="text/javascript" src="cform.js"></script>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0" style="height:100%; border:solid 3px #f6005d; background-color:#f6005d;">
  <tr>
    <td align="center" valign="middle" class="style2" style=" background-repeat:no-repeat; width:100%; height:100%; background-position:center center;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center"><img src="images/SUC.jpg" alt="topalign launching soon, html, seo, UI, web, graphic designing." width="1211" height="562" border="2">

<div id="form">
<form><table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td class="brd">
		   <div class="mg">
		      <p align="center" style="font-size:18px;">Contact topalign</p>
			
              <table width="100%" border="0" align="center" cellpadding="4" cellspacing="0" class="form">
                <tr> 
                  <td width="44%"><label>Full Name:</label></td>
                  <td width="56%"><input type="text" id="name" size="30" /></td>
                </tr>
                <tr> 
                  <td><label>Your Email:</label></td>
                  <td><input type="text" id="email" size="30" /></td>
                </tr>
                <tr> 
                  <td><label>Your Subject:</label></td>
                  <td><input type="text" id="subject" size="30" /></td>
                </tr>
                <tr> 
                  <td valign="top"><label>Your Message:</label></td>
                  <td><textarea name="body" rows="4" id="body"></textarea></td>
                </tr>
                <tr align="center"> 
                  <td colspan="2"><input type="button" value="Submit" id="submit" onClick="return check_values();"></td>
                </tr>
              </table>
            </div>           </td></tr></table>
              </form>
        <div id="confirmation" style="display:none;" align="center">..</div>
	</div>
        
        <img src="images/advertisment21042008.gif" alt="TopAlign introductory offer_ UI and Web Designer at 15000Rs/month" width="504" height="360" border="2" longdesc="http://jaisonje.com"></td>
        </tr><tr><td><div class="style1">
          <div align="center">Designer  = 15000Rs/month, Web site Designing +  Domain +  Hosti<a href="totalcontent.html" target="_blank"><img src="images/advertisment1.gif" alt="TopAlign introductory offer_ UI and Web Designer at 15000Rs/month" width="5" height="5" border="0" longdesc="http://jaisonje.com"></a>ng = 6000Rs, Graphic Designing = 200Rs/Hour or 12000Rs/month.          </div>
          <p align="center"><strong>Home:</strong>Cheap rate web designing, Cheap rate grapic designing, Cheap rate UI desiging, world wide web designer, world wide web designs,  Web designer, UI designer, flash designer, SEO expert, Technopark, infopark, Photography, Site optimization, Image optimization, web 2.0, PSD, HTML, DHTML,  India, kerala, Website Re-designing, Website Maintenance            </p>
          <p align="center"><strong>Certifications:</strong>            Brain Bench certified designers: http://www.brainbench.com/xml/bb/transcript/public/viewtranscript.xml</p>
          <p align="center"><strong>Major search engines:</strong>            Download a free application desktop application:
            Topalign Directory with googlr search :- always in your desktop
            Using Software : dream waver, Photoshop, flash, fireworks, In design, illustrator, 
            
            Freelance web designer Topalign produces highest quality interactive web sites, logos, templates and flash animations. As you have already noticed my specialization is professional web site design and maintenance.
            
            As a professional website designer, I have successfully worked with partners and customers from worldwide via the internet.</p>
          <p align="center"><strong>About us:</strong> Mr. Elayidom working as a ui engineer in technopark (Kerala IT)
            
            
            Portfolio:
            Logo:
            Website: 
            Website's design is of greatest significance for a successful presence on the web for your business. Nowadays websites are increased for business and also personal purposes. We apply specific, measurable business goals to create sites and web design solutions that really help you to Bring in more quality enquiries, Increase sales revenue, Make your business more efficient, Improve your customer service.
            Website Re-Design 
            WebSite re-designing of your existing web sites to incorporate searchable keywords & descriptions, improve visual quality & download time and expand or focus sites with changed as a new eyecatching design & SEO friendly website.
            
            UI designs:
            Flash:
            Web design:
            LetterHead design:
            Identity design:
            
            Graphics:
            Photographs:
            
            Services:
            Topalign SEO service is the place to come for personalized service for all of your search engine optimization needs. Topalign SEO service offers aggressive, yet ethical search engine optimization methodology to get your websites to the top of the rankings without getting penalized or banned. Most larger firms do not offer a guarantee of their services, but Topalign SEO service offers a 99-percent satisfaction guarantee. It is a risk for SEO Expert of offer a guarantee, but Topalign SEO service is so confident on the results for your website that a guarantee If you're paying for results and do not get actual result, then you deserve to get a refund.</p>
          <p align="center"><strong>Contact Us</strong>:
            Mr. JJ Elayidom
            Elayidathu house
            Thodupuzha po
            Thodupuzha
            Pin 685584
            Mobile: 9895933339 mailat: topalign@gmail.com</p>
        </div>
        </td>
      </tr>
    </table></td>
  </tr>
</table>
<span class="style2">
<!-- Start of StatCounter Code -->
<img src="http://c44.statcounter.com/3636292/0/f0cafbcb/0/" alt="hit counter" border="0">
<!-- End of StatCounter Code -->
</span>
</body>
</html>
